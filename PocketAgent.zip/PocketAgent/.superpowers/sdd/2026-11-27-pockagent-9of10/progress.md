﻿# SDD ledger - plan: C:\Users\Sanjib\AppData\Local\Temp\opencode\pockagent-plan\docs\superpowers\plans\2026-11-27-pockagent-9of10.md
Setup: Ruling: no bash and no local JDK/Gradle/Android SDK - reproduce ledger scripts in PowerShell and use GitHub Actions push runs as RED/GREEN gate - costs one CI round-trip per TDD step.
Setup: Ruling: one long-lived branch hardening/9of10 with per-task commits instead of 11 stacked PR branches - tasks share the MainActivity seam; final review range cut from merge-base.
Pre-flight: Task1->Task2: Task 1 removes compile error so Task 2 can get green baseline; no conflict.
Pre-flight: Task2->Task3: Task 2 removes contents:write so Task 3 workflow edits inherit read-only; no conflict.
Pre-flight: Task3->Task4: docs use versionCode 13/1.6.1 from Task 3; no conflict.
Pre-flight: Task4->Task5/6/7/8/9/10/11: evidence doc is appended, not overwritten, by later tasks; no conflict.
Pre-flight: Task5->Task7: SHA sidecar API is consumed by initModels wiring in the same task; no conflict.
Pre-flight: Task6->Task7/8: store read/write API unchanged; ViewModel keeps existing constructor; no conflict.
Pre-flight: Task7->Task8: MainActivity owns viewModel; extraction moves UI only; no conflict.
Pre-flight: Task8->Task9/10: controllers preserve UI helpers used by design and tests; no conflict.
Pre-flight: Task9->Task10: tokens and checklist consumed by screenshot/smoke tests; no conflict.
Pre-flight: Task10->Task11: reports and run URLs feed final audit; no conflict.
